#define UNKNOWN_PIN 0xFF

extern void testInitialisation();
void test_initialisation_complete(void);
void test_initialisation_ports(void);
void test_initialisation_outputs_V03(void);
void test_initialisation_outputs_V04(void);
void test_initialisation_outputs_MX5_8995(void);
uint8_t getPinMode(uint8_t);