void testPW();
void test_PW_No_Multiply();
void test_PW_MAP_Multiply(void);
void test_PW_AFR_Multiply(void);
void test_PW_MAP_Multiply_Compatibility(void);
void test_PW_ALL_Multiply(void);
void test_PW_Large_Correction();
void test_PW_Very_Large_Correction();